import { useState, useEffect } from "react";
import { supabase } from "../supabase";
import { useNavigate } from "react-router-dom";
import "../styles/MoneyMuse.css";

const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

export default function MoneyMuse() {
  const navigate = useNavigate();
  const [transactions, setTransactions] = useState([]);
  const [goals, setGoals] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    amount: "",
    category: "",
    note: "",
    date: new Date().toISOString().split("T")[0],
    account_id: "",
    is_income: false,
  });

  const now = new Date();
  const monthLabel = `${MONTHS[now.getMonth()]} ${now.getFullYear()}`;

  useEffect(() => { fetchAll(); }, []);

  async function fetchAll() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const [{ data: txns }, { data: gs }, { data: accs }] = await Promise.all([
      supabase.from("mm_transactions").select("*").eq("user_id", user.id).order("date", { ascending: false }).limit(20),
      supabase.from("mm_savings_goals").select("*").eq("user_id", user.id),
      supabase.from("mm_accounts").select("*").eq("user_id", user.id),
    ]);
    if (txns) setTransactions(txns);
    if (gs) setGoals(gs);
    if (accs) setAccounts(accs);
  }

  const income = transactions.filter(t => t.amount > 0).reduce((s, t) => s + Number(t.amount), 0);
  const spent = transactions.filter(t => t.amount < 0).reduce((s, t) => s + Math.abs(Number(t.amount)), 0);
  const left = income - spent;
  const pct = income > 0 ? Math.min(Math.round((spent / income) * 100), 100) : 0;

  const byCategory = transactions
    .filter(t => t.amount < 0)
    .reduce((acc, t) => {
      const cat = t.category || "Other";
      acc[cat] = (acc[cat] || 0) + Math.abs(Number(t.amount));
      return acc;
    }, {});
  const catEntries = Object.entries(byCategory).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const maxCat = catEntries[0]?.[1] || 1;

  const set = (field) => (e) => setForm(f => ({ ...f, [field]: e.target.value }));

  async function handleAdd(e) {
    e.preventDefault();
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    const amt = form.is_income ? Math.abs(Number(form.amount)) : -Math.abs(Number(form.amount));
    await supabase.from("mm_transactions").insert({
      user_id: user.id,
      account_id: form.account_id || null,
      amount: amt,
      category: form.category,
      note: form.note,
      date: form.date,
      source: "manual",
    });
    setLoading(false);
    setShowModal(false);
    setForm({ amount: "", category: "", note: "", date: new Date().toISOString().split("T")[0], account_id: "", is_income: false });
    fetchAll();
  }

  return (
    <div className="mm-root">
      <nav className="mm-nav">
        <button className="mm-back" onClick={() => navigate("/dashboard")}>←</button>
        <span className="mm-nav-title">Money Muse</span>
      </nav>

      <div className="mm-main">

        <div className="mm-overview">
          <div className="mm-overview-row">
            <div className="mm-stat"><span className="mm-stat-label">Income</span><span className="mm-stat-val green">${income.toLocaleString()}</span></div>
            <div className="mm-stat"><span className="mm-stat-label">Spent</span><span className="mm-stat-val orange">${spent.toLocaleString()}</span></div>
            <div className="mm-stat"><span className="mm-stat-label">Left</span><span className="mm-stat-val">${left.toLocaleString()}</span></div>
          </div>
          <div className="mm-bar"><div className="mm-bar-fill" style={{ width: `${pct}%` }} /></div>
          <div className="mm-bar-meta"><span>{pct}% spent</span><span>{monthLabel}</span></div>
        </div>

        <div className="mm-grid">
          <div className="mm-card">
            <div className="mm-card-title">By category</div>
            {catEntries.length === 0 ? <p className="mm-empty">No expenses yet</p> : (
              <div className="mm-bars">
                {catEntries.map(([cat, amt]) => (
                  <div className="mm-bar-col" key={cat}>
                    <div className="mm-bar-col-fill" style={{ height: `${Math.round((amt / maxCat) * 100)}%` }} />
                    <span className="mm-bar-col-label">{cat.slice(0, 6)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="mm-card">
            <div className="mm-card-title">Savings goals</div>
            {goals.length === 0 ? <p className="mm-empty">No goals yet</p> : (
              <div className="mm-goals">
                {goals.map(g => {
                  const gpct = Math.min(Math.round((g.current_amount / g.target_amount) * 100), 100);
                  return (
                    <div className="mm-goal" key={g.id}>
                      <div className="mm-goal-row">
                        <span className="mm-goal-name">{g.name}</span>
                        <span className="mm-goal-amt">${g.current_amount}/${g.target_amount}</span>
                      </div>
                      <div className="mm-goal-bar">
                        <div className="mm-goal-fill" style={{ width: `${gpct}%`, background: "#E85D26" }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        <div className="mm-card">
          <div className="mm-card-title">Recent transactions</div>
          {transactions.length === 0 ? (
            <p className="mm-empty">No transactions yet — tap + to add one</p>
          ) : (
            <div className="mm-txns">
              {transactions.map(t => (
                <div className="mm-txn" key={t.id}>
                  <div className="mm-txn-icon">{t.amount > 0 ? "💼" : categoryIcon(t.category)}</div>
                  <div className="mm-txn-info">
                    <div className="mm-txn-name">{t.note || t.category}</div>
                    <div className="mm-txn-cat">{t.category} · {new Date(t.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</div>
                  </div>
                  <span className={`mm-txn-amt ${t.amount > 0 ? "pos" : "neg"}`}>
                    {t.amount > 0 ? "+" : "-"}${Math.abs(Number(t.amount)).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

      <button className="mm-fab" onClick={() => setShowModal(true)}>+</button>

      {showModal && (
        <div className="mm-modal-bg" onClick={(e) => { if (e.target === e.currentTarget) setShowModal(false); }}>
          <div className="mm-modal">
            <div className="mm-modal-handle" />
            <div className="mm-modal-title">Add transaction</div>
            <form onSubmit={handleAdd}>
              <div className="mm-type-toggle">
                <button type="button" className={!form.is_income ? "active" : ""} onClick={() => setForm(f => ({ ...f, is_income: false }))}>Expense</button>
                <button type="button" className={form.is_income ? "active" : ""} onClick={() => setForm(f => ({ ...f, is_income: true }))}>Income</button>
              </div>
              <div className="mm-modal-row">
                <div className="mm-modal-field">
                  <label>Amount</label>
                  <input type="number" placeholder="0.00" value={form.amount} onChange={set("amount")} required min="0" step="0.01" />
                </div>
                <div className="mm-modal-field">
                  <label>Category</label>
                  <input type="text" placeholder="e.g. Food" value={form.category} onChange={set("category")} required />
                </div>
              </div>
              <div className="mm-modal-field">
                <label>Note</label>
                <input type="text" placeholder="What was this for?" value={form.note} onChange={set("note")} />
              </div>
              <div className="mm-modal-row">
                <div className="mm-modal-field">
                  <label>Account</label>
                  <select value={form.account_id} onChange={set("account_id")}>
                    <option value="">No account</option>
                    {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                  </select>
                </div>
                <div className="mm-modal-field">
                  <label>Date</label>
                  <input type="date" value={form.date} onChange={set("date")} required />
                </div>
              </div>
              <button className="mm-modal-btn" type="submit" disabled={loading}>
                {loading ? "Adding…" : "Add transaction"}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function categoryIcon(cat) {
  const c = (cat || "").toLowerCase();
  if (c.includes("food") || c.includes("eat") || c.includes("grocer")) return "🛒";
  if (c.includes("transport") || c.includes("car") || c.includes("uber")) return "🚗";
  if (c.includes("bill") || c.includes("util")) return "⚡";
  if (c.includes("shop") || c.includes("cloth")) return "🛍";
  if (c.includes("health") || c.includes("med")) return "💊";
  if (c.includes("coffee") || c.includes("cafe")) return "☕";
  return "💳";
}
